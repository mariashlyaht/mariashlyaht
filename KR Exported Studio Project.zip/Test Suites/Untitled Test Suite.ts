<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Untitled Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>d19384df-0cc8-4c8a-8862-0fa3de450600</testSuiteGuid>
   <testCaseLink>
      <guid>2985cc49-3c3a-4aa9-86e0-341b3d40a701</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Untitled Test Suite/Untitled Test Case</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>8a471dfb-320a-4a55-b774-b4190b65aa89</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Untitled Test Suite/Untitled Test Case (1)</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f4318613-ffb2-448d-bab6-f76e8895729b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Untitled Test Suite/Untitled Test Case (2)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    